<?php
require_once("myClass.php");
include 'conect.php';
// Оголошуємо змінні
$userNameIsUnique=true;
$passwordIsValid=true;
$userIsEmpty=false;
$passwordIsEmpty=false;
$password2IsEmpty=false;
// Перевіряємо, чи запит сторінки відбувся з неї самої методом POST
if ($_SERVER["REQUEST_METHOD"] == "POST"){
// Перевіряємо, чи користувач заповнив своє ім'я в текстовому полі "Ваше ім'я:"
    if ($_POST["user"]==""){
        $userIsEmpty=true;
    }
// Створюємо з'єднання з базою даних
    $userID= myClass::getInstance()->get_user_id_by_name($_POST["user"]);
    if ($userID) {
        $userNameIsUnique=false;
    }
// Перевіряємо, чи пароль був введений та правильно підтверджений
    if ($_POST["password"]=="")
    $passwordIsEmpty=true;
    if ($_POST["password2"]=="")
    $password2IsEmpty=true;
    if ($_POST["password"]!=$_POST["password2"]) {
        $passwordIsValid=false;
    }
/*Перевіряємо логічні зачення, які показують, що вихідні дані були успішно
*перевірені. Якщо вхідні дані були успішно підтверджені, то додаємо їх, як
*новий запис у таблицю "wishers" бази даних. Після додавання нового запису,
закриваємо з'єднання і перенаправляємо програму до editWishList.php*/
    if (!$userIsEmpty && $userNameIsUnique && !$passwordIsEmpty &&
            !$password2IsEmpty && $passwordIsValid) {
        myClass::getInstance()->create_user($_POST["user"],$_POST["password"]);
        session_start();
        $_SESSION["user"]=$_POST["user"];
        header("Location: hom.php");
        exit;
    }
}
?>
<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
        <title>Регістрація</title>
        <meta name="viewport" content="width=device-width">
        <link href="/projects/Kurs/css/bootstrap.min.css" rel="stylesheet">
        <link href="/projects/Kurs/signin.css" rel="stylesheet">
        <link href="wishlist.css" type="text/css" rel="stylesheet" media="all" />
    </head>
    <body>
     <div class="container">
       <form class="form-signin" action="registration.php" method="post">
            <h2 class="form-signin-heading">Регістація</h2>
            <label for="text" class="sr-only">Login</label>
            <input type="text" id="inputLogin" class="form-control" placeholder="Login" name="user" required autofocus>
            <br />
            <?php
/* Відображаємо повідомлення про помилки, якщо текстове поле "Ваше ім'я:"
є порожнім або вже існує користувач з таким ім'ям*/
            if ($userIsEmpty) {
                echo ('<div class="error">Вкажіть, будь ласка, Ваше імя</div>');
//echo ("Вкажіть, будь ласка, Ваше імя");
//                echo ("<br />");
            }
            if (!$userNameIsUnique) {
                echo ('<div class="error">Особа з таким імям вже існує. Просимо змінити та
    спробувати знову</div>');
//echo ("Особа з таким імям вже існує. Просимо змінити та спробувати знову");
//                echo ("<br />");
            }
            ?>
            <label for="inputPassword" class="sr-only">Password</label>
            <input type="password" id="inputPassword" class="form-control" placeholder="Password" name="password" required>
            <br />
            <?php
/* Відображаємо повідомлення про помилки, якщо текстове поле "Пароль:"
є порожнім*/
            if ($passwordIsEmpty) {
                echo ('<div class="error">Введіть, будь ласка, пароль</div>');
            }
            ?>
            <label for="inputPassword" class="sr-only">Password</label>
            <input type="password" id="inputPasswordR" class="form-control" placeholder="Password" name="password2" required>
            <?php
/* Відображаємо повідомлення про помилки, якщо текстове поле "Прошу підтвердити
свій пароль:" є порожнім або його вміст не збігається з полем "Пароль:"*/
            if ($password2IsEmpty) {
                echo ('<div class="error">Підтвердіть, будь ласка, свій пароль</div>');
            }
            if (!$password2IsEmpty && !$passwordIsValid) {
                echo ('<div class="error">Паролі не співпадають!</div>');             
            }
            ?>
            <br />
            <button class="btn btn-lg btn-primary btn-block" type="submit">Регістрація</button>
      </form>
    </div> <!-- /container -->
		<!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
    <!-- Include all compiled plugins (below), or include individual files as needed -->
    <script src="/projects/Kurs/js/bootstrap.min.js"></script>
    </body>
</html>
