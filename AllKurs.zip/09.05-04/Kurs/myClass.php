<?php
class myClass extends mysqli {
// Один екземпляр загальний для всіх екземплярів
    private static $instance=null;
// Змінні конфігурації з'єднання з базою даних
    private $user="root";
    private $pass="1111";
    private $dbName="kurs";
    private $dbHost="localhost";

/*Ця функція повинна бути static і повертати екземпляр класу,
 якщооб'єкт ще не існує.*/
    public static function getInstance() {
        if (!self::$instance instanceof self) {
            self::$instance=new self;
        }
        return self::$instance;
    }

/*Функції clone і wakeup запобігають зовнішньому створенню об'єктів копій
 *одноекземплярного класу, виключаючи таким чином можливість появи об'єктів,
  які дублюються.*/
    public function __clone() {
        trigger_error("Клон не допускається.",E_USER_ERROR);
    }

    public function __wakeup() {
        trigger_error("Дисеріалізація не допускається.",E_USER_ERROR);
    }

// Конструктор
    private function __construct() {
    parent::__construct($this->dbHost,$this->user,$this->pass,$this->dbName);
        if (mysqli_connect_error()) {
            exit("Помилка зєднання (".mysqli_connect_errno().")"
                    .mysqli_connect_error());
        }
// Встановлюємо набір символів за замовчуванням.
        parent::set_charset("utf-8");
        $this->query("set_client='utf8'");
        $this->query("set character_set_results='utf8'");
        $this->query("set collation_connection='utf8_general_ci'");
        $this->query("SET NAMES utf8");
    }

    public function get_user_id_by_name($name) {
        $name=$this->real_escape_string($name);
        $user=$this->query("SELECT id FROM users WHERE name='"
                        .$name."'");

        if ($user->num_rows > 0){
            $row=$user->fetch_row();
            return $row[0];
        } else
            return null;
    }

    public function get_exp()
    {
    return $this->query("SELECT id,name_ekspoz,name_ekspon,num_ekpon,avtor,data,img,misce FROM eks");
    }
    public function get_expoz()
    {
        return $this->query("SELECT id,name,opus,dotup,img FROM ekspoz");
    }

    public function create_user($name,$password) {
        $name=$this->real_escape_string($name);
        $password=$this->real_escape_string($password);
        $this->query("INSERT INTO users (name,password) VALUES ('".$name
                ."','".$password."')");
    }
    ///////my  func for EKSPOZ 
    public function edd_ekspoz($name,$opus,$dotup)
    {
       $name=$this->real_escape_string($name);
       $opus=$this->real_escape_string($opus);
       $dotup=$this->real_escape_string($dotup);
       $this->query("INSERT INTO `kurs`.`ekspoz` (`id`, `name`, `opus`, `dotup`, `img`) VALUES ('NULL','".$name."','".$opus."','".$dotup."',' ')");
    }
    public function update_ekspoz($id,$name,$dotup,$opus)
    {
        //$description=$this->real_escape_string($description);
        /* @var $dotup type */
        $this->query("UPDATE `kurs`.`ekspoz` SET `name` = '".$name."', `dotup` = '".$dotup."', `opus` = '".$opus."' WHERE `ekspoz`.`id` = ".$id."");
    }
    public function delete_ekspoz($id)
    {
        $this->query("DELETE FROM `kurs`.`ekspoz` WHERE id=".$id);
    }
    //END my  func for EKSPOZ 
    //Search funk
    // my func for eksponat
    public function edd_eks($name_ekspoz,$name_ekspon,$num_ekpon,$avtor,$data,$misce)
    {
        $name_ekspoz=  $this->real_escape_string($name_ekspoz);
        $name_ekspon=  $this->real_escape_string($name_ekspon);
        $num_ekpon=  $this->real_escape_string($num_ekpon);
        $avtor=  $this->real_escape_string($avtor);
        $data=  $this->real_escape_string($data);
        $misce=  $this->real_escape_string($misce);
        $this->query("INSERT INTO `kurs`.`eks` (`id`, `name_ekspoz`, `name_ekspon`, `num_ekpon`, `avtor`, `data`, `img`, `misce`) VALUES (NULL, '".$name_ekspoz."', '".$name_ekspon."', '".$num_ekpon."', '".$avtor."', '".$data."', '', '".$misce."')");
    }
    public function update_eks($id,$name_ekspoz,$name_ekspon,$num_ekpon,$avtor,$data,$misce)
    {
        $id=  $this->real_escape_string($id);
        $name_ekspoz=  $this->real_escape_string($name_ekspoz);
        $name_ekspon=  $this->real_escape_string($name_ekspon);
        $num_ekpon=  $this->real_escape_string($num_ekpon);
        $avtor=  $this->real_escape_string($avtor);
        $data=  $this->real_escape_string($data);
        $misce=  $this->real_escape_string($misce);
        $this->query("UPDATE `kurs`.`eks` SET `name_ekspoz` = '".$name_ekspoz."', `name_ekspon` = '".$name_ekspon."', `num_ekpon` = '".$num_ekpon."', `avtor` = '".$avtor."', `data` = '".$data."', `misce` = '".$misce."' WHERE `eks`.`id` = ".$id."");
        
    }
    public function delete_eks($id)
    {
        $this->query("DELETE FROM `kurs`.`eks` WHERE id=".$id);
    }

    

    //END my func for eksponat

    public function search_eks($key)
    {
        $key=  $this->real_escape_string($key);
                //return $this->query("SELECT * FROM `kurs`.`eks` WHERE (CONVERT(`id` USING utf8) LIKE '%".$key."%' OR CONVERT(`name_ekspoz` USING utf8) LIKE '%".$key."%' OR CONVERT(`name_ekspon` USING utf8) LIKE '%".$key."%' OR CONVERT(`num_ekpon` USING utf8) LIKE '%".$key."%' OR CONVERT(`avtor` USING utf8) LIKE '%".$key."%' OR CONVERT(`data` USING utf8) LIKE '%".$key."%' OR CONVERT(`img` USING utf8) LIKE '%".$key."%' OR CONVERT(`misce` USING utf8) LIKE '%".$key."%'");
                //return $this->query("SELECT * FROM `kurs`.`eks` WHERE (CONVERT(`name_ekspon` USING utf8) LIKE '%".$key."%')");
                //return $this->query("select * from `kurs`.`eks` where concat(CONVERT('name_ekspon' USING utf8),'name_ekspon','avtor') like '%".$key."%'");
                return $this->query("SELECT * FROM eks WHERE (name_ekspon LIKE '%$key%' OR avtor LIKE '%$key%' OR name_ekspoz LIKE '%$key%' OR num_ekpon LIKE '%$key%' OR data LIKE '%$key%' OR id LIKE '%$key%' )");

    }
    public function search_ekspoz($key)
    {
        $key=  $this->real_escape_string($key);
                //return $this->query("SELECT * FROM `kurs`.`eks` WHERE (CONVERT(`id` USING utf8) LIKE '%".$key."%' OR CONVERT(`name_ekspoz` USING utf8) LIKE '%".$key."%' OR CONVERT(`name_ekspon` USING utf8) LIKE '%".$key."%' OR CONVERT(`num_ekpon` USING utf8) LIKE '%".$key."%' OR CONVERT(`avtor` USING utf8) LIKE '%".$key."%' OR CONVERT(`data` USING utf8) LIKE '%".$key."%' OR CONVERT(`img` USING utf8) LIKE '%".$key."%' OR CONVERT(`misce` USING utf8) LIKE '%".$key."%'");
                //return $this->query("SELECT * FROM `kurs`.`eks` WHERE (CONVERT(`name_ekspon` USING utf8) LIKE '%".$key."%')");
                //return $this->query("select * from `kurs`.`eks` where concat(CONVERT('name_ekspon' USING utf8),'name_ekspon','avtor') like '%".$key."%'");
                return $this->query("SELECT * FROM ekspoz WHERE (id LIKE '%$key%' OR name LIKE '%$key%' OR opus LIKE '%$key%' OR dotup LIKE '%$key%')");

    }
    public function open_ekspoz($key)
    {
                $key=  $this->real_escape_string($key);
                return $this->query("SELECT * FROM eks WHERE(name_ekspoz LIKE '%$key%')");
    }
    public function verify_user_credentials($name,$password) {
        $name=$this->real_escape_string($name);
        $password=$this->real_escape_string($password);
        $result=$this->query("SELECT 1 FROM users WHERE name='"
                        .$name."' AND password='".$password."'");
        return $result->data_seek(0);
    }
    public function check($name){
         $admin="Адміністратор";
         $user="Користувач ";
         $name=$this->real_escape_string($name);
         $amin=$this->query("SELECT amin FROM users WHERE name='".$name."'");
         $row=mysqli_fetch_array($amin);
         $a2=$row['amin'];
         if($a2==="1")
         {
             return $admin;
         }
         else
         {
           return $user;
         }
    }
    /*function insert_wish($wisherID,$description,$duedate) {
        $description=$this->real_escape_string($description);
        if ($this->format_date_for_sql($duedate)==null){
           $this->query("INSERT INTO wishes (wisher_id,description)"
                   ." VALUES (".$wisherID.",'".$description."')");
        } else
        $this->query("INSERT INTO wishes (wisher_id,description,due_date)"
                ." VALUES (".$wisherID.",'".$description."',"
                .$this->format_date_for_sql($duedate).")");
    }
    */
    /*function format_date_for_sql($date) {
        if ($date=="")
            return null;
        else {
        $dateParts=date_parse($date);
  return $dateParts["year"]*10000+$dateParts["month"]*100+$dateParts["day"];
        }
    }*/

    

    public function get_wish_by_wish_id($wishID) {
        return $this->query("SELECT id,description,due_date FROM wishes WHERE
            id=".$wishID);
    }

    
}
?>
