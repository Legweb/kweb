<?php
        
        require_once("myClass.php");
        include_once("ses.php");
        //error_reporting(0);
        ?>
<html>
  <head>
    <title>Перегляд експонатів</title>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width">
     <link href="/projects/Kurs/css/bootstrap.min.css" rel="stylesheet">
    <link href="/projects/Kurs/signin.css" rel="stylesheet">
    <link href="/projects/Kurs/css/general.css" rel="stylesheet">
    <link href='https://fonts.googleapis.com/css?family=Lobster&subset=latin,cyrillic' rel='stylesheet' type='text/css'>

  </head>
  
  <body>
      <nav class="navbar navbar-inverse" data-spy="affix" data-offset-top="197">
  <div class="container-fluid">
    <div class="navbar-header">
        <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
          <span class="icon-bar"></span>
          <span class="icon-bar"></span>
          <span class="icon-bar"></span>  
          <span class="icon-bar"></span>
          <span class="icon-bar"></span>
      </button>
        <a class="navbar-brand" href="hom.php"><span class="glyphicon glyphicon-home"></span></a>
    </div>
    <div>
      <div class="collapse navbar-collapse" id="myNavbar">
        <ul class="nav navbar-nav">
          <li><a href="hom.php#section1">Нові експозиції</a></li>
          <li><a href="hom.php#section2">Перегляд</a></li>
          <li><a href="hom.php#section3">Квитки та екскурсії</a></li>
          <li><a href="hom.php#section4">Контакти та місцезнаходження</a></li>
          <li class="dropdown"><a class="dropdown-toggle" data-toggle="dropdown" href="#"><span class="glyphicon glyphicon-search"></span> <span class="caret"></span></a>
            <ul class="dropdown-menu li">
                <li class="li" ><a href="searchEkspoz.php"><span class="glyphicon glyphicon-search"></span> Пошук по експозиціям</a></li>
                <li><a href="search.php"><span class="glyphicon glyphicon-search"></span> Пошук по експонатам</a></li>
            </ul>
          </li>
         <li class="nick">
          <?php
          
                  echo '<a href "#"> '.$mes.' '.$status.' </a>';
          ?>
          </li>
           <li>
                    <div class="exitb">
                        <table border="0" cellspacing="10">
                            
                                <tr>
                                    <td>
                                        <form method="post" action="session_exit.php">
                                            <button class="btn btn-primary " type="submit"><span class="glyphicon glyphicon-log-out"></span></button>
                                        </form>
                                    </td>
                                    <td>&nbsp;&nbsp;&nbsp;</td>
                                    <td>
                                       <button class="btn btn-primary " type="submit"><span class="glyphicon  glyphicon-envelope"></span></button>

                                    </td>
                                </tr>
                            
                        </table>

                            

                    </div>
                </li>
        </ul>
      </div>
    </div>
  </div>
</nav> 
      
      <div class="row">
          <?php
          if($status==="Адміністратор")
          {
              echo '<div class="row">
              <div class="add" >
                  <a class="btn btn-info" href="eddEks.php"><span class="glyphicon glyphicon-plus	Try it
"></span> Додати експоната</a>
                  
              </div>
          </div>';
          }
          ?>
          
          <div id="main">
      <?php
            require_once("myClass.php");
            $result=  myClass::getInstance()->get_exp();
            while ($row=mysqli_fetch_array($result)) {
                
               $id=$row["id"];
               $name_ekspoz=$row["name_ekspoz"];
               $name_ekspon=$row["name_ekspon"];
               $num_ekpon=$row["num_ekpon"];
               $avtor=$row["avtor"];
               $data=$row["data"];
               $misce=$row["misce"];
               $img=$row["img"];

            echo 
               '<div class="col-sm-6 col-md-4">
                   <div class="thumbnail">
                        <img src="'.  strip_tags($img).'"  alt="1"/>
                        <div class="caption">
                          <table class="table table-striped">
    
    <tbody>
      <tr>
        <td>Назва експонату</td>
        <td>'.strip_tags($name_ekspon).'</td>
      </tr>
      <tr>
        <td>В експозиції</td>
        <td>'.strip_tags($name_ekspoz).'</td>
      </tr>
      <tr>
        <td>№</td>
        <td>'.strip_tags($num_ekpon).'</td>
      </tr>
      <tr>
        <td>Автор</td>
        <td>'.strip_tags($avtor).'</td>
      </tr>
      <tr>
        <td>Дата</td>
        <td>'.strip_tags($data).'</td>
      </tr>
      <tr>
        <td>Розташування</td>
        <td>'.strip_tags($misce).'</td>
      </tr>
      
    </tbody>
  </table>';
          $s1=$status;
          if($status==="Адміністратор")
              {
              echo '<div id="centered">
                          <table >
                            <tr>
                              <th>
                              <form name="view" action="updateEks.php" method="POST">
            <input type="hidden" name="id" value='.$id.' />
            <input type="hidden" name="name_ekspoz" value='.$name_ekspoz.' />
            <input type="hidden" name="name_ekspon" value='.$name_ekspon.' />
            <input type="hidden" name="num_ekpon" value='.$num_ekpon.' />
            <input type="hidden" name="avtor" value='.$avtor.' />
            <input type="hidden" name="data" value='.$data.' />  
            <input type="hidden" name="misce" value='.$misce.' />
            <button type="submit" name="updateEks" class="btn btn-warning"> <span class="glyphicon glyphicon-pencil"></span> Змінити</button>

                </form>
                              </th>
                              <th>&nbsp;&nbsp;&nbsp;</th>
                              <th>
                               <form name="view" action="delEks.php" method="POST">
                                <input type="hidden" name="id1" value='.$id.' />
                                <!--<input type="submit" class="btn btn-primary" name="deleteWish" value="Вилучити" ></input>-->
                                <button type="submit" class="btn btn-danger" name="deleteWish" ><span class="glyphicon glyphicon-trash"></span> Вилучити</button>
                                </form>
                              </th>
                            </tr>
                            <tr>
                            
                            
                            </tr>
                          </table>
                          </div>
                          
                           </div>
                    </div>
                  </div>';
          }
          else
          {
          echo '  </div>
                    </div>
                  </div>';
          }
               
               
            }
            mysqli_free_result($result);
            ?>
  
          </div>   
</div>
          <a href="#" class="scrollup"></a>



      
    <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
    <!-- Include all compiled plugins (below), or include individual files as needed -->
    <script src="/projects/Kurs/js/bootstrap.min.js"></script>
    <script src="/projects/Kurs/js/scrol_top.js" ></script>
  </body>
</html>