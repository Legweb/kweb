<?php
require_once("myClass.php");
include 'conect.php';
// Оголошуємо змінні
if ($_SERVER["REQUEST_METHOD"] == "POST"){
myClass::getInstance()->delete_ekspoz($_POST["id"]);
}
?>
<html>
  <head>
    <title>Видалення експозиції</title>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width">
     <link href="/projects/Kurs/css/bootstrap.min.css" rel="stylesheet">
    <link href="/projects/Kurs/signin.css" rel="stylesheet">
  </head>
  <body>
    <div class="container">

        <form class="form-horizontal" action="deleteEkspoz.php" method="post">
            <fieldset>

            <!-- Form Name -->
            
            <!-- Text input-->
            <div class="form-group">
              
              <label class="col-md-4 control-label" for="textinput">Введіть ід експозиції, яку треба видалити</label>  
              <div class="col-md-4">
              <input id="textinput" name="id" type="text" placeholder="placeholder" class="form-control input-md"> 
              </div>
            </div>
            
            <!-- Button -->
            <div class="form-group">
              <label class="col-md-4 control-label" for="singlebutton">  </label>
              <div class="col-md-4">
            <button class="btn btn-lg btn-primary btn-block" type="submit">Видалити експозицію</button>
              </div>
            </div>

            </fieldset>
            </form>

    </div> <!-- /container -->



    <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
    <!-- Include all compiled plugins (below), or include individual files as needed -->
    <script src="/projects/Kurs/js/bootstrap.min.js"></script>
  </body>
</html>