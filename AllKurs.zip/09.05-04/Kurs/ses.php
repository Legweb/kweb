    <?php
        
        require_once("myClass.php");
        session_start();
        $mes=" ";
        $status;
        if (array_key_exists("user",$_SESSION))
        {
            $mes= "".$_SESSION["user"];
        }
        $status= myClass::getInstance()->check($_SESSION['user']);
        

        ?>

