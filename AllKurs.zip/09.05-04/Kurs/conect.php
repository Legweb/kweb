<html>
<body> 
    <?php 
    $con=mysqli_connect("localhost","root","1111");
    if (!$con) {
       exit ("Connect Error (".mysqli_connect_errno().")"
              .mysqli_connect_error());
    }

    ?>
</body>
</html>
