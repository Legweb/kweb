<!DOCTYPE html>

<html>
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
        <title>Перегляд</title>
     <link href="wishlist.css" type="text/css" rel="stylesheet" media="all" />
    </head>
    <body>
     
        <?php
        
        require_once("myClass.php");
        session_start();
        if (array_key_exists("user",$_SESSION))
        {
            echo "Hello ".$_SESSION["user"];
        }

        ?>
        <table class="std">
            <tr>
                <th>id</th>
                <th>Назва експозиції</th>
                <th>Назва експонату</th>
                <th>Номер експонату</th>
                <th>Автор</th>
                <th>Дата</th>
                <th>Росташування</th>
                <th>Фото</th>
                <th> </th>
            </tr>
            <?php
            $result=  myClass::getInstance()->get_exp();
            while ($row=mysqli_fetch_array($result)) {
                
               $id=$row["id"];
               $name_ekspoz=$row["name_ekspoz"];
               $name_ekspon=$row["name_ekspon"];
               $num_ekpon=$row["num_ekpon"];
               $avtor=$row["avtor"];
               $data=$row["data"];
               $misce=$row["misce"];
               $img=$row["img"];

               echo "<tr><td>&nbsp;".strip_tags($id,"<br /><p><h1>")."</td>";
               echo "<td>&nbsp;".strip_tags($name_ekspoz)."</td>";
               echo "<td>&nbsp;".strip_tags($name_ekspon)."</td>";
               echo "<td>&nbsp;".strip_tags($num_ekpon)."</td>";
               echo "<td>&nbsp;".strip_tags($avtor)."</td>";
               echo "<td>&nbsp;".strip_tags($data)."</td>";
               echo "<td>&nbsp;".strip_tags($misce)."</td>";
               echo '<td>
                <form name="view" action="delEks.php" method="POST">
            <input type="hidden" name="id1" value='.$id.' />
            <input type="submit" name="deleteWish" value="Вилучити" />
                </form></td>';
               echo '<td>
                <form name="view" action="updateEks.php" method="POST">
            <input type="hidden" name="id" value='.$id.' />
            <input type="hidden" name="name_ekspoz" value='.$name_ekspoz.' />
            <input type="hidden" name="name_ekspon" value='.$name_ekspon.' />
            <input type="hidden" name="num_ekpon" value='.$num_ekpon.' />
            <input type="hidden" name="avtor" value='.$avtor.' />
            <input type="hidden" name="data" value='.$data.' />  
            <input type="hidden" name="misce" value='.$misce.' />
            <input type="submit" name="updateEks" value="Змінити" />
                </form></td>';
               
               echo "<td><img src=".strip_tags($img)." alt=".strip_tags($name_ekspon)."/></td></tr>\n";
               
            }
            mysqli_free_result($result);
            ?>
        </table>
        <h2>Ekspoz</h2>
        <table class="std">
            <tr>
                <th>id</th>
                <th>Назва експозиції</th>
                <th>Опис</th>
                <th>Доступ</th>
                <th> </th>
                <th>Фото</th>
            </tr>
            <?php
            //use myClass;
            //return $this->query("SELECT id,name,opud,dotup,img FROM ekspoz");
                   
            /*if ($_SERVER["REQUEST_METHOD"] == "POST"){
            myClass::getInstance()->delete_ekspoz($id);
            }*/
            $result2= myClass::getInstance()->get_expoz();
            while ($row1=mysqli_fetch_array($result2)) {
               $id1=$row1["id"];
               $name=$row1["name"];
               $opus=$row1["opus"];
               $dotup=$row1["dotup"];
               $img=$row1["img"];
               echo "<tr><td>&nbsp;".strip_tags($id1,"<br /><p><h1>")."</td>";
               echo "<td>&nbsp;".strip_tags($name)."</td>";
               echo "<td>&nbsp;".strip_tags($opus)."</td>";
               echo "<td>&nbsp;".strip_tags($dotup)."</td>";
               echo '<td>
                <form name="view" action="delEkspoz.php" method="POST">
            <input type="hidden" name="id1" value='.$id1.' />
            <input type="submit" name="deleteWish" value="Вилучити" />
                </form></td>';
               echo '<td>
                <form name="view" action="updateEkspoz.php" method="POST">
            <input type="hidden" name="id1" value='.$id1.' />
            <input type="hidden" name="name" value='.$name.' />
            <input type="hidden" name="opus" value='.$opus.' />
            <input type="hidden" name="dotup" value='.$dotup.' />
            <input type="submit" name="updateEkspoz" value="Змінити" />
                </form></td>';
               echo "<td><img src=".strip_tags($img)." alt=".strip_tags($name)."/></td></tr>\n";
             
            }
            mysqli_free_result($result2);
            ?>
        </table>
    </body>
</html>

