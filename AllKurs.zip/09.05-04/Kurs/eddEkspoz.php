<?php
require_once("myClass.php");
include 'conect.php';
// Оголошуємо змінні
if ($_SERVER["REQUEST_METHOD"] == "POST"){
myClass::getInstance()->edd_ekspoz($_POST["name"],$_POST["opus"],$_POST["dotup"]);
}
?>
<html>
  <head>
    <title>Додавання експозиції</title>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width">
     <link href="/projects/Kurs/css/bootstrap.min.css" rel="stylesheet">
    <link href="/projects/Kurs/signin.css" rel="stylesheet">
  </head>
  <body>
    <div class="container">

        <form class="form-horizontal" action="eddEkspoz.php" method="post">
            <fieldset>

            <!-- Form Name -->
            

            <!-- Text input-->
            <div class="form-group">
              
              <label class="col-md-4 control-label" for="textinput">Введіть ім'я експозиції</label>  
              <div class="col-md-4">
              <input id="textinput" name="name" type="text" placeholder="placeholder" class="form-control input-md"> 
              </div>
            </div>

            <!-- Text input-->
            <div class="form-group">
              <label class="col-md-4 control-label" for="textinput">Введіть доступність експозиції</label>  
              <div class="col-md-4">
              <input id="textinput" name="dotup" type="text" placeholder="placeholder" class="form-control input-md">
              </div>
            </div>

            <!-- Textarea -->
            <div class="form-group">
              <label class="col-md-4 control-label" for="textarea">Введіть опис експозиції</label>
              <div class="col-md-4">                     
                <textarea class="form-control" id="textarea" name="opus"></textarea>
              </div>
            </div>
            <!-- Button -->
            <div class="form-group">
              <label class="col-md-4 control-label" for="singlebutton">  </label>
              <div class="col-md-4">
            <button class="btn btn-lg btn-primary btn-block" type="submit">Додавання експозиції</button>
              </div>
            </div>

            </fieldset>
            </form>

    </div> <!-- /container -->



    <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
    <!-- Include all compiled plugins (below), or include individual files as needed -->
    <script src="/projects/Kurs/js/bootstrap.min.js"></script>
  </body>
</html>