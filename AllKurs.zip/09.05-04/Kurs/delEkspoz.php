<?php
  require_once("myClass.php");
  myClass::getInstance()->delete_ekspoz($_POST["id1"]);
  //header("Location: plut.php");
  echo 'good!';
?>
