    <?php
        
        require_once("myClass.php");
        require_once("ses.php");
        $status= myClass::getInstance()->check($_SESSION['user']);
        

        ?>
<!DOCTYPE html>
<html>
<head>
  <title>Експозиція</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.0/jquery.min.js"></script>
  <script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>
  <script src="/projects/Kurs/js/section_animate.js"></script>
  <link href='https://fonts.googleapis.com/css?family=Lobster&subset=latin,cyrillic' rel='stylesheet' type='text/css'>
  <link rel="stylesheet" href="/projects/Kurs/css/general.css">
  <link rel="stylesheet" href="/projects/Kurs/css/animate.css">
	
	
	
</head>
<body data-spy="scroll" data-target=".navbar" data-offset="50">



<nav class="navbar navbar-inverse" data-spy="affix" data-offset-top="197">
  <div class="container-fluid">
    <div class="navbar-header">
        <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
          <span class="icon-bar"></span>
          <span class="icon-bar"></span>
          <span class="icon-bar"></span>  
          <span class="icon-bar"></span>
          <span class="icon-bar"></span>
      </button>
      <a class="navbar-brand" href="#"><span class="glyphicon glyphicon-home"></span></a>
    </div>
    <div>
      <div class="collapse navbar-collapse" id="myNavbar">
        <ul class="nav navbar-nav">
          <li><a href="#section1">Нові експозиції</a></li>
          <li><a href="#section2">Перегляд</a></li>
          <li><a href="#section3">Квитки та екскурсії</a></li>
          <li><a href="#section4">Контакти та місцезнаходження</a></li>
          <li class="dropdown"><a class="dropdown-toggle" data-toggle="dropdown" href="#"><span class="glyphicon glyphicon-search"></span> <span class="caret"></span></a>
            <ul class="dropdown-menu li">
                <li class="li" ><a href="searchEkspoz.php"><span class="glyphicon glyphicon-search"></span> Пошук по експозиціям</a></li>
                <li><a href="search.php"><span class="glyphicon glyphicon-search"></span> Пошук по експонатам</a></li>
            </ul>
          </li>
         
          <li class="nick">
          
          <?php
          
                  echo '<a href "#"> '.$mes.' '.$status.' </a>';
          ?>
              
          
          </li>
           <li>
                    <div class="exitb">
                        <table border="0" cellspacing="10">
                            
                                <tr>
                                    <td>
                                        <form method="post" action="session_exit.php">
                                            <button class="btn btn-primary " type="submit"><span class="glyphicon glyphicon-log-out"></span></button>
                                        </form>
                                    </td>
                                    <td>&nbsp;&nbsp;&nbsp;</td>
                                    <td>
                                       <button class="btn btn-primary " type="submit"><span class="glyphicon  glyphicon-envelope"></span></button>

                                    </td>
                                </tr>
                            
                        </table>

                            

                    </div>
            </li>
            </li>
                     
           <li>
        </ul>
      </div>
    </div>
  </div>
</nav> 
    

<div id="section1" class="container-fluid">
    <div id="myCarousel" style="" class="carousel slide" data-ride="carousel">
    <!-- Indicators -->
    <ol class="carousel-indicators">
      <li data-target="#myCarousel" data-slide-to="0" class="active"></li>
      <li data-target="#myCarousel" data-slide-to="1"></li>
      <li data-target="#myCarousel" data-slide-to="2"></li>
      <li data-target="#myCarousel" data-slide-to="3"></li>
    </ol>

    <!-- Wrapper for slides -->
    <div class="carousel-inner" role="listbox" >

      <div class="item active blockimage">
          <img src="img/carosel/kocka_vesna_v_celi.jpg" alt="Chania" >
        <div class="carousel-caption">
          <h3> Коцка</h3>
          <p>Весна в селі</p>
        </div>
      </div>

        <div class="item blockimage" >
            <img  src="img/carosel/manaylo_1958_selo_v_gorah.jpg" alt="Chania">
        <div class="carousel-caption">
          <h3> Манайло</h3>
          <p>Село в горах</p>
        </div>
      </div>
    
      <div class="item">
          <img src="img/carosel/nasturcij.jpg" alt="Flower" >
        <div class="carousel-caption">
          <h3> Труш</h3>
          <p>Настирсії</p>
        </div>
      </div>

      <div class="item">
          <img src="img/carosel/nayurmort_Erdely_1946.jpg" alt="Flower" >
        <div class="carousel-caption">
          <h3> Ерделі</h3>
          <p>Натютморд</p>
        </div>
      </div>
  
    </div>

    <!-- Left and right controls -->
    <a class="left carousel-control" href="#myCarousel" role="button" data-slide="prev">
      <span class="glyphicon glyphicon-chevron-left" aria-hidden="true"></span>
      <span class="sr-only">Previous</span>
    </a>
    <a class="right carousel-control" href="#myCarousel" role="button" data-slide="next">
      <span class="glyphicon glyphicon-chevron-right" aria-hidden="true"></span>
      <span class="sr-only">Next</span>
    </a>
  </div>
</div>
    
    <!--       -->
<div id="section2" class="container-fluid">
  
<div class="row">
  <div class="col-sm-6 col-md-6 padbot2 ">
      <div class="caption">
          
          <button class="btnimg" type="submit"  onclick="location.href='plut.php'" ></button>
      </div>
      
  </div>
  <div class="col-sm-6 col-md-6 padbot2" >
    <div class="caption">
          <button class="btnimg2"  type="submit" onclick="location.href='plut2.php'" ></button>
      </div>
  </div>
    
</div>
</div>
<div id="section3" class="container-fluid">
   
    <div class="col-sm-4 col-md-4 padbox">
        <div class="centered textb">
        <span class="glyphicon glyphicon-tags size"></span>
        
        <h3>Ціна квитків</h3>
                
                <li>Стандартний:30грн</li>
                <li>Для студентів та школяр: 15грн</li>
                <li>Для дітей до 10 років 5 грн</li>
                <br> 
                <br> 
        <button type="submit" class="btn btn-info" ><span class="glyphicon glyphicon-credit-card"></span>  Квитки</button>
        </div>
        </div>
       <div class="col-sm-4 col-md-4 padbox">
        <div class="centered textb">
        <span class="glyphicon glyphicon-time size"></span>
        
        <h3>Графік роботи</h3>
        <li>Вт-Пт: 11:00-19</li>
        <li>Сб-Нд: 11:00-17:00</li>
        <li>Пн: вихідний</li>
        </div>
        </div>
   
    
    <div class="col-sm-4 col-md-4 padbox">
        <div class="centered textb">
        <span class="glyphicon glyphicon-user size"></span>
        
        <h3>Екскурії</h3>
                
                <li>Індивідуальна:80грн</li>
                <li>Для групи до 8 чол:200грн</li>
                <li>Для групи до 20 чол:330грн</li>
                <br> 
                <br>  
        <button type="submit" class="btn btn-info" ><span class="glyphicon glyphicon-user"></span>  Екскурсії</button>
        </div>
        </div>
   
   
</div>
<div id="section4" class="container-fluid">
<div id="googleMap" style="width:auto;height:380px;"></div>

</div>
<div id="section41" class="container-fluid">
  <div class="col-sm-3 col-md-4 padbox">
        <div class="centered">
        <span class="glyphicon glyphicon-phone size2"></span>
        </div>
      <div class="centered2 textb">
          <br/>
        <p>+380320000000</p>
        <p>+380320000000</p>
        <p>+380320000000</p>
      </div> 
   </div>
    <div class="col-sm-3 col-md-4 padbox">
        <div class="centered">
        <span class="glyphicon glyphicon-envelope size2"></span>
        </div>
      <div class="centered2">
          <br/>
          <p class="textb">galary@galary.ua</p>
      </div> 
   </div>
    <div class="col-sm-3 col-md-4 padbox">
        <div class="centered">
        <span class="glyphicon glyphicon-map-marker size2"></span>
        </div>
      <div class="centered2">
          <br/>
          <p class="textb">вул.Генерала Чупринки 103<br>
           м.Львів Львівська область<br>
           &nbsp;&nbsp;&nbsp;79000</p>
      </div> 
   </div>
</div>
    <div id="sectionEnd" style="width:auto;height:60px;" ></div>

</body>
</html>
