<?php
        
        require_once("myClass.php");
        include_once("ses.php");
        //error_reporting(0);
        ?>
<html>
  <head>
    <title>Перегляд експозицій</title>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width">
     <link href="/projects/Kurs/css/bootstrap.min.css" rel="stylesheet">
    <link href="/projects/Kurs/signin.css" rel="stylesheet">
    <link href="/projects/Kurs/css/general.css" rel="stylesheet">
    <link href='https://fonts.googleapis.com/css?family=Lobster&subset=latin,cyrillic' rel='stylesheet' type='text/css'>

  </head>
  
  <body>
      <nav class="navbar navbar-inverse" data-spy="affix" data-offset-top="197">
  <div class="container-fluid">
    <div class="navbar-header">
        <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
          <span class="icon-bar"></span>
          <span class="icon-bar"></span>
          <span class="icon-bar"></span>  
          <span class="icon-bar"></span>
          <span class="icon-bar"></span>
      </button>
        <a class="navbar-brand" href="hom.php"><span class="glyphicon glyphicon-home"></span></a>
    </div>
    <div>
      <div class="collapse navbar-collapse" id="myNavbar">
        <ul class="nav navbar-nav">
          <li><a href="hom.php#section1">Нові експозиції</a></li>
          <li><a href="hom.php#section2">Перегляд</a></li>
          <li><a href="hom.php#section3">Квитки та екскурсії</a></li>
          <li><a href="hom.php#section4">Контакти та місцезнаходження</a></li>
          <li class="dropdown"><a class="dropdown-toggle" data-toggle="dropdown" href="#"><span class="glyphicon glyphicon-search"></span> <span class="caret"></span></a>
            <ul class="dropdown-menu li">
                <li class="li" ><a href="searchEkspoz.php"><span class="glyphicon glyphicon-search"></span> Пошук по експозиціям</a></li>
                <li><a href="search.php"><span class="glyphicon glyphicon-search"></span> Пошук по експонатам</a></li>
            </ul>
          </li>
         <li class="nick">
          <?php
          
                  echo '<a href "#"> '.$mes.' '.$status.' </a>';
          ?>
          </li>
          <li>
                    <div class="exitb">
                        <table border="0" cellspacing="10">
                            
                                <tr>
                                    <td>
                                        <form method="post" action="session_exit.php">
                                            <button class="btn btn-primary " type="submit"><span class="glyphicon glyphicon-log-out"></span></button>
                                        </form>
                                    </td>
                                    <td>&nbsp;&nbsp;&nbsp;</td>
                                    <td>
                                       <button class="btn btn-primary " type="submit"><span class="glyphicon  glyphicon-envelope"></span></button>

                                    </td>
                                </tr>
                            
                        </table>

                            

                    </div>
                </li>
        </ul>
      </div>
    </div>
  </div>
</nav> 
      <div class="row">
          <?php
          if($status==="Адміністратор")
          {
              echo '<div class="row">
              <div class="add" >
                  <a class="btn btn-info" href="eddEkspoz.php"><span class="glyphicon glyphicon-plus	Try it
"></span> Додати експоната</a>
                  
              </div>
          </div>';
          }
          ?>
          
          <div id="main">
      <?php
            require_once("myClass.php");
            $result=  myClass::getInstance()->get_expoz();
            while ($row=mysqli_fetch_array($result)) {
                
               $id1=$row["id"];
               $name=$row["name"];
               $opus=$row["opus"];
               $dotup=$row["dotup"];
               $img=$row["img"];

            echo 
               '<div class="col-sm-8 col-md-6">
                   <div class="thumbnail">
                        <img src="'.  strip_tags($img).'" alt="1"/>
                        <div class="caption">
                          <table class="table table-striped">
    
    <tbody>
      <tr>
        <td>Назва експозиції</td>
        <td>'.strip_tags($name).'</td>
      </tr>
      <tr>
        <td>Опис</td>
        <td>'.strip_tags($opus).'</td>
      </tr>
      <tr>
        <td>Доступність для відвідування</td>
        <td>'.strip_tags($dotup).'</td>
      </tr>
      
      
    </tbody>
  </table>
  <form name="view" action="plutOpen.php" method="POST">
   <input type="hidden" name="name" value='.$name.' />
    <button type="submit" class="btn btn-info btn-block" ><span class="glyphicon glyphicon-check"></span>Перегяд</button>
   </form>
  
  
                          
                          <p>
                          <div id="centered">
                          <table >
                          
                            <tr>
                              <th>
          <form name="view" action="updateEkspoz.php" method="POST">
            <input type="hidden" name="id1" value='.$id1.' />
            <input type="hidden" name="name" value='.$name.' />
            <input type="hidden" name="opus" value='.$opus.' />
            <input type="hidden" name="dotup" value='.$dotup.' />
            <button type="submit" name="updateEks" class="btn btn-warning"> <span class="glyphicon glyphicon-pencil"></span> Змінити</button>
          </form>
                              </th>
                              <th>&nbsp;&nbsp;&nbsp;</th>
                              <th>
                               <form name="view" action="delEkspoz.php" method="POST">
                                    <input type="hidden" name="id1" value='.$id1.' />
                                    <button type="submit" class="btn btn-danger" name="deleteWish" ><span class="glyphicon glyphicon-trash"></span> Вилучити</button>
                                </form>
                              </th>
                            </tr>
                          </table>
                          </div>
                          
                           </div>
                    </div>
                  </div>';
               
            }
            mysqli_free_result($result);
            ?>

  
          </div>   
</div>


      
    <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
    <!-- Include all compiled plugins (below), or include individual files as needed -->
    <script src="/projects/Kurs/js/bootstrap.min.js"></script>
  </body>
</html>