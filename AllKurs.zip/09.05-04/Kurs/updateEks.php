<?php
require_once("myClass.php");
include 'conect.php';
  
// Оголошуємо змінні
if ($_SERVER["REQUEST_METHOD"] == "POST"){
myClass::getInstance()->update_eks($_POST["id"],$_POST["name_ekspoz"],$_POST["name_ekspon"],$_POST["num_ekpon"],$_POST["avtor"],$_POST["data"],$_POST["misce"]);
}
?>
<html>
  <head>
    <title>Оновлення експозиції</title>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width">
     <link href="/projects/Kurs/css/bootstrap.min.css" rel="stylesheet">
    <link href="/projects/Kurs/signin.css" rel="stylesheet">
  </head>
  <body>
    <div class="container">

        <form class="form-horizontal" action="updateEks.php" method="post">
            <fieldset>

            <!-- Form Name -->
            
            <!-- Text input-->
            <div class="form-group">
              
              <label class="col-md-4 control-label" for="textinput">Id експозиції</label>  
              <div class="col-md-4">
                  <input id="textinput" name="id" readonly="" value="<?=$_POST['id'];?>" type="text" placeholder="placeholder" class="form-control input-md"> 
              </div>
            </div>
            <!-- Text input-->
            <div class="form-group">
              
              <label class="col-md-4 control-label" for="textinput">Введіть ім'я експозиції</label>  
              <div class="col-md-4">
                  <input id="textinput" name="name_ekspoz" value="<?=$_POST['name_ekspoz'];?>" type="text" placeholder="placeholder" class="form-control input-md"> 
              </div>
            </div>

            <!-- Text input-->
            <div class="form-group">
              <label class="col-md-4 control-label" for="textinput">Введіть імя експонату</label>  
              <div class="col-md-4">
                  <input id="textinput" name="name_ekspon" value="<?=$_POST['name_ekspon'];?>" type="text" placeholder="placeholder" class="form-control input-md">
              </div>
            </div>

            <!-- Textarea -->
            <div class="form-group">
              <label class="col-md-4 control-label" for="textarea">Введіть номер експонату</label>
              <div class="col-md-4">                     
                  <input id="textinput" name="num_ekpon" value="<?=$_POST['num_ekpon'];?>" type="text" placeholder="placeholder" class="form-control input-md">
              </div>
            </div>
            <!-- Textarea -->
            <div class="form-group">
              <label class="col-md-4 control-label" for="textarea">Введіть автора</label>
              <div class="col-md-4">                     
                  <input id="textinput" name="avtor" value="<?=$_POST['avtor'];?>" type="text" placeholder="placeholder" class="form-control input-md">
              </div>
            </div>
            <!-- Textarea -->
            <div class="form-group">
              <label class="col-md-4 control-label" for="textarea">Введіть дату</label>
              <div class="col-md-4">                     
                  <input id="textinput" name="data" value="<?=$_POST['data'];?>" type="text" placeholder="placeholder" class="form-control input-md">
              </div>
            </div>
            <!-- Textarea -->
            <div class="form-group">
              <label class="col-md-4 control-label" for="textarea">Введіть росташування</label>
              <div class="col-md-4">                     
                  <input id="textinput" name="misce" value="<?=$_POST['misce'];?>" type="text" placeholder="placeholder" class="form-control input-md">
              </div>
            </div>
            <!-- Button -->
            <div class="form-group">
              <label class="col-md-4 control-label" for="singlebutton">  </label>
              <div class="col-md-4">
            <button class="btn btn-lg btn-primary btn-block" type="submit">Оновити експозиціюї</button>
              </div>
            </div>

            </fieldset>
            </form>

    </div> <!-- /container -->



    <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
    <!-- Include all compiled plugins (below), or include individual files as needed -->
    <script src="/projects/Kurs/js/bootstrap.min.js"></script>
  </body>
</html>