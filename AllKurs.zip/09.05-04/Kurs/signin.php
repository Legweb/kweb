<?php
require_once("myClass.php");
$logonSuccess=false;
$corect=true;
// Перевіряємо обліковий запис
if ($_SERVER["REQUEST_METHOD"]=="POST") {
$logonSuccess=(myClass::getInstance()->verify_user_credentials($_POST["user"],
        $_POST["password"]));
    if ($logonSuccess==true) {
        session_start();
        $_SESSION["user"]=$_POST["user"];
        header("Location: hom.php");
        exit;
    }
    else
    {
        $corect=FALSE;
    }
    
}
?>
<html>
  <head>
    <title>TODO supply a title</title>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width">
     <link href="/projects/Kurs/css/bootstrap.min.css" rel="stylesheet">
    <link href="/projects/Kurs/signin.css" rel="stylesheet">
  </head>
  <body>
    <div class="container">

        <form action="signin.php" method="post" class="form-signin">
        <h2 class="form-signin-heading">Please sign in</h2>
        <label for="text" class="sr-only">Login</label>
        <input type="text" id="inputLogin" class="form-control" placeholder="Login" name="user" required autofocus>
        <label for="inputPassword" class="sr-only">Password</label>
        <input type="password" id="inputPassword" class="form-control" placeholder="Password" name="password" required>
        <button class="btn btn-lg btn-primary btn-block" type="submit">Sign in</button>
        <?php
        if(!$corect)
        {
            echo '<p>Користувач не зарегістрований </p>';
        }
        ?>
      </form>

    </div> <!-- /container -->



    <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
    <!-- Include all compiled plugins (below), or include individual files as needed -->
    <script src="/projects/Kurs/js/bootstrap.min.js"></script>
  </body>
</html>

