-- phpMyAdmin SQL Dump
-- version 4.1.4
-- http://www.phpmyadmin.net
--
-- Хост: 127.0.0.1
-- Час створення: Трв 10 2016 р., 04:11
-- Версія сервера: 5.6.15-log
-- Версія PHP: 5.4.24

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- База даних: `kurs`
--

-- --------------------------------------------------------

--
-- Структура таблиці `eks`
--

CREATE TABLE IF NOT EXISTS `eks` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name_ekspoz` varchar(50) CHARACTER SET utf8 NOT NULL,
  `name_ekspon` varchar(50) CHARACTER SET utf8 NOT NULL,
  `num_ekpon` int(11) NOT NULL,
  `avtor` varchar(50) CHARACTER SET utf8 NOT NULL,
  `data` varchar(30) CHARACTER SET utf8 NOT NULL,
  `img` varchar(80) CHARACTER SET utf8 NOT NULL,
  `misce` varchar(30) CHARACTER SET utf8 NOT NULL,
  `size` varchar(45) CHARACTER SET utf8 NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=30 ;

--
-- Дамп даних таблиці `eks`
--

INSERT INTO `eks` (`id`, `name_ekspoz`, `name_ekspon`, `num_ekpon`, `avtor`, `data`, `img`, `misce`, `size`) VALUES
(2, 'Труш', 'Лебеді', 2, 'Труш', '1898', '/projects/Kurs/img/trusho/lebedy.jpg', '1', '157х60х18'),
(5, 'Труш', 'Кущ у снігу', 3, 'Труш', '1903', '/projects/Kurs/img/trusho/kush_u_snigu.jpg', 'Перший', '129х57х21'),
(3, 'Труш', 'Гора', 17, 'Труш', '1929', '/projects/Kurs/img/trusho/zahid_sonca_y_lisi.jpg', 'Другий зал', '124х100х20'),
(4, 'Труш', 'Феодосія Крим', 565, 'Труш ', '1904', '/projects/Kurs/img/trusho/feodosia_krum.jpg', '3', '167х123х30'),
(6, 'Труш', 'Далекі гори', 1, 'Олег Труш', '1903', '/projects/Kurs/img/trusho/daleki_horu.jpg', 'Перший зал', '260x169x34'),
(7, 'Труш', 'Місячна ніч над морем', 43, 'Труш', '1908', '/projects/Kurs/img/trusho/misjchna_nich_nad_morem.jpg', 'Перший зал', '200х139х31'),
(8, 'Труш', 'Настирсій', 23, 'Труш', '1805', '/projects/Kurs/img/trusho/nasturcij.jpg', 'Другий зал', '123х48х14'),
(9, 'Труш', 'Самотня сосна', 45, 'Труш', '1906', '/projects/Kurs/img/trusho/samotny_sosna.jpg', 'Другий зал', '145х55х15'),
(10, 'Труш', 'Травнева ніч', 42, 'Труш', '1905', '/projects/Kurs/img/trusho/travneva_nich.jpg', 'Другий зал', '120х68х18'),
(11, 'Труш', 'Трембарі', 42, 'Труш', '1904', '/projects/Kurs/img/trusho/trembitari.jpg', 'Другий зал', '191х134х46'),
(12, 'Труш', 'Захід сонця у лісі', 53, 'Труш', '1911', '/projects/Kurs/img/trusho/zahid_sonca_y_lisi.jpg', 'Другий зал', '159х59х33'),
(13, 'Закарпатська школа', 'Хустсьький замок', 35, 'Бокшай', '1950', '/projects/Kurs/img/zak_shola/hust_zamok1942.jpg', 'Третій зал', '239х156х14'),
(14, 'Коцка А.А.', 'Стара церква', 45, 'Коцка', '1960', '/projects/Kurs/img/zak_shola/kocka_1970_stara_cerkva.jpg', 'Третій зал', '234х156х31'),
(15, 'Коцка А.А.', 'Село Холмок', 43, 'Коцка', '1960', '/projects/Kurs/img/zak_shola/kocka_1983_celo_holmok.jpg', 'Третій зал', '356х257х14'),
(16, 'Коцка А.А.', 'На полонині Рохнески', 45, 'Коцка', '1980', '/projects/Kurs/img/zak_shola/kocka_na_polonyny_Rohnesku_1980.jpg', 'Третій зал', '349х246х21'),
(17, 'Коцка А.А.', 'На Рахівщині', 46, 'Коцка', '1982', '/projects/Kurs/img/zak_shola/Kocka_na_rahivzHuni.jpg', 'Третій зал', '389х200х19'),
(18, 'Коцка А.А.', 'Весна у селі', 47, 'Коцка', '1987', '/projects/Kurs/img/zak_shola/kocka_vesna_v_celi.jpg', 'Третій зал', '250х180х34'),
(19, 'Коцка А.А.', 'Під Говерлою', 48, 'Коцка', '1988', '/projects/Kurs/img/zak_shola/kocka_vodoshovuzhe_pid_Hoverlou_1980.jpg', 'Третій', '299х187х20'),
(20, 'Закарпатська школа', 'Гірська панорама', 49, 'Майло', '1960', '/projects/Kurs/img/zak_shola/majlo_horna_panorama_1960.jpg', 'Четвертий зал', '239х156х14'),
(21, 'Закарпатська школа', 'Голуба піч', 56, 'Манайло', '1965', '/projects/Kurs/img/zak_shola/manajlo_holuba_pich.jpg', 'Четвертий зал', '260x169x34'),
(22, 'Закарпатська школа', 'Манайло', 51, 'Майло', '1964', '/projects/Kurs/img/zak_shola/manajlo_lisopulka.jpg', 'Четвертий зал', '124х100х20'),
(23, 'Закарпатська школа', 'Село в горах', 57, 'Манайло', '1960', '/projects/Kurs/img/zak_shola/manaylo_1958_selo_v_gorah.jpg', 'Четвертий зал', '200х139х31'),
(24, 'Закарпатська школа', 'Натюрморд', 78, 'Ерделі', '1968', '/projects/Kurs/img/zak_shola/nayurmort_Erdely_1946.jpg', 'Четвертий зал', '200х139х31'),
(25, 'Коцка А.А.', 'Озеро у горах', 68, 'Коцка', '1959', '/projects/Kurs/img/zak_shola/Ozero__horah_kocka.jpg', 'Четвертий зал', '200х139х31'),
(26, 'Закарпатська школа', 'Панорама Ужгорода', 67, 'Бокшай', '1970', '/projects/Kurs/img/zak_shola/panorama_uzgoroda1948.jpg', 'Сьомий зал', '200х139х31'),
(27, 'Закарпатська школа', 'Під полонинами', 78, 'Кашшай', '1971', '/projects/Kurs/img/zak_shola/Pid_pulepeckumu_polonunamu_1960_Kashshay.jpg', 'Сьомий зал', '255х177х22'),
(28, 'Закарпатська школа', 'Ужгородський замок', 77, 'Габда', '1970', '/projects/Kurs/img/zak_shola/Uz_zamok_1970_Gabda.jpg', 'Сьомий зал', '200х139х31'),
(29, 'Закарпатська школа', 'Вивіз лісу', 79, 'Борецкій', '1950', '/projects/Kurs/img/zak_shola/Vuviz_lisu_1950_Boreckiy.jpg', 'Сьомий зал', '239х156х14');

-- --------------------------------------------------------

--
-- Структура таблиці `ekspoz`
--

CREATE TABLE IF NOT EXISTS `ekspoz` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(30) CHARACTER SET utf8 NOT NULL,
  `opus` varchar(100) CHARACTER SET utf8 NOT NULL,
  `dotup` varchar(30) CHARACTER SET utf32 NOT NULL,
  `img` varchar(100) CHARACTER SET utf8 NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Дамп даних таблиці `ekspoz`
--

INSERT INTO `ekspoz` (`id`, `name`, `opus`, `dotup`, `img`) VALUES
(0, 'Труш', 'Картини', 'Недоступна', '/projects/Kurs/img/trusho/zahid_sonca_y_lisi.jpg'),
(1, 'Закарпатська школа', 'Відомий художник із закарпаття', 'Доступна', '/projects/Kurs/img/zak_shola/nayurmort_Erdely_1946.jpg'),
(2, 'Коцка А.А.', 'Твори А. Коцки оригінальні за стилем і відрізняються бездоганним колоритом. Своєрідною візитівкою ху', 'Доступна', '/projects/Kurs/img/zak_shola/kocka_vodoshovuzhe_pid_Hoverlou_1980.jpg');

-- --------------------------------------------------------

--
-- Структура таблиці `users`
--

CREATE TABLE IF NOT EXISTS `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `password` varchar(50) CHARACTER SET utf8 NOT NULL,
  `amin` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=5 ;

--
-- Дамп даних таблиці `users`
--

INSERT INTO `users` (`id`, `name`, `password`, `amin`) VALUES
(1, 'Oleh', '1111', 0),
(2, 'Olya', 'lol', 0),
(3, 'Ivan', 'koko', 0),
(4, 'Ostap', '2323', 1);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
